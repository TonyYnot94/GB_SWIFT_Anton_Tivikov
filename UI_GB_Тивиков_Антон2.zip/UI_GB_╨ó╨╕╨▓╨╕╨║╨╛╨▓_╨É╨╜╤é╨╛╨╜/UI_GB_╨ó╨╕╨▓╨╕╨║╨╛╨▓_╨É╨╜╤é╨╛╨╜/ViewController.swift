//
//  ViewController.swift
//  UI_GB_Тивиков_Антон
//
//  Created by Антон Тивиков on 03.11.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

